const express = require("express");
const router = express.Router();
const { add, display, search } = require("../../controllers/product");
const { ADD, DISPLAY, SEARCH } = require("../../utils/config").ROUTES.PRODUCT;

router.post(ADD, add);
router.get(DISPLAY, display);
router.post(SEARCH, search);
module.exports = router;
